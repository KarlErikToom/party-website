
;* * FOR WINDOWS 2000 USER * *
 * Installation Instructions *

  1. Boot up Windows 2000.

  2. Click the "Start" Button, point to "Settings" and then click "Control Panel".

  3. Double-click "Display".

  4. Click the "Settings" Tab.

  5. Click "Advanced...".
	
  6. Click the "Monitor" Tab.
	
  7. Click "Properties".

  8. Click the "Driver" Tab.

  9. Click the "Update Driver".

     This opens the "Update Driver Wizard".

  9. Click "Next >".

 10. If you are installing from FD insert it into your disk drive.

 11. Click "Display a list of all the drivers..." and "Next >".

 12. Click "Have Disk...".
	
 13. Click Browse and navigate to where you stored the driver and select the location that matches your model and click OK.

 14. Click "Show all hardware".

 15. Select "Manufacturer: Iiyama".

 16. Select the model name that matches your monitor then click "Next >".

 17. Follow the screen instructions to complete the installation.

 NOTE: You may get a warning window "Digital Signature Not Found".
       To continue the install click "Yes". 


;* NOTES FOR NT USER *
 * ***************** *

 NT does not have the device category of 'MONITOR'.
 Driver files are not required for monitor setup. 
