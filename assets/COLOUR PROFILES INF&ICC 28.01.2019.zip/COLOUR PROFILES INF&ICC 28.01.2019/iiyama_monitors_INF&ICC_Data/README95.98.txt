
;* ** FOR WINDOWS 98 USER ** *
 * Installation Instructions *

        1. Boot up Windows 98.

        2. Click the "Start" Button, point to "Settings" and then click "Control Panel".

        3. Double-click "Display".

        4. Click the "Setting"Tab.

	5. Click "Advanced...".
	
	6. Click "Monitor"Tab.
	
	7. Click "Change...".

	8. Click "Next >".

        9. Insert this FD in your disk drive.

       10. Click "Display a list of all the drivers..." and "Next >".

       11. Click "Have Disk...".
	
       12. Click Browse and navigate to where you stored the driver and select the location that matches your model and click OK.

       13. Click the model name that matches your monitor.

       14. Follow the screen instructions to complete the installation.

;* ** FOR WINDOWS 95 USER ** *
 * Installation Instructions *

        1. Boot up Windows 95.

        2. Click the "Start" Button, point to "Settings" and then click "Control Panel".

        3. Double-click "Display".

        4. Click the "Setting"Tab.

        5. Click "Change Display Type".

        6. Click "Change..." Button of the "Monitor Type".

        7. Insert this FD in your disk drive.

        8. Click "Have Disk...".

        9. Click Browse and navigate to where you stored the driver and select the location that matches your model and click OK.

       10. Click the model name that matches your monitor.

       11. Follow the screen instructions to complete the installation.
          
          
;* NOTES FOR NT USER *
 * ***************** *

 NT does not have the device category of 'MONITOR'.
 Driver files are not required for monitor setup. 
