
;* FOR WINDOWS 98 SECOND EDITION & WINDOWS MILLENIUM USER *
 * ************** Installation Instructions ************* *

  1. Boot up Windows 98SE / Windows Me.

  2. Click the "Start" Button, point to "Settings" and then click "Control Panel".

  3. Double-click "Display".

  4. Click the "Settings" Tab.

  5. Click "Advanced...".
	
  6. Click the "Monitor" Tab.
	
  7. Click "Change...".

  8. Click "Next >".

  9. If you are installing from FD insert it into your disk drive.

 10. Click "Display a list of all the drivers..." and "Next >".

 11. Click "Have Disk...".
	.
 12. Click Browse and navigate to where you stored the driver and select the location that matches your model and click OK.

 13. Click "Show all hardware".

 14. Select "Manufacturer: Iiyama".

 15. Select the model name that matches your monitor then click "Next >".

 16. Follow the screen instructions to complete the installation.


;* NOTES FOR NT USER *
 * ***************** *

 NT does not have the device category of 'MONITOR'.
 Driver files are not required for monitor setup. 
