iiyama MONITOR DRIVERS - README FIRST
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There are 4 README files to aid driver installation:

README2000.TXT ---- Windows 2000
README95.98.TXT --- Windows 95 & 98 (first edition)
README98SE.Me.TXT - Windows 98 Second Edition & Me (Millenium edition)
READMEXP.TXT ---- Windows XP
 
Please Note:
	Windows NT & Mac OS do not have the device category of 'MONITOR'.
 	Driver files are not required for monitor setup with these operating systems.