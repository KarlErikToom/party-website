
;* FOR WINDOWS XP USER *
 * ************** Installation Instructions ************* *

  1. Boot up Windows XP.

  2. Click the "Start" Button, point to "Settings" and then click "Control Panel".

  3. Double-click "Display".

  4. Click the "Settings" Tab.

  5. Click "Advanced...".
	
  6. Click the "Monitor" Tab.
	
  7. Click the "Properties" button.

  8. Click the "Monitor" tab.

  9. Click the "Driver" tab and slect "Update Driver"

 10. Select "Install from a specific location" and "Next"

 11. Select "Don't Search" and "Next"

 12. If you are installing from FD insert it into your disk drive.

 13. Click "Have Disk...".
	
 14. Click Browse and navigate to where you stored the driver and select the location that matches your model and click OK.

 15. Click "Show all hardware".

 16. Select "Manufacturer: Iiyama".

 17. Select the model name that matches your monitor then click "Next >".

 18. Follow the screen instructions to complete the installation.


;* NOTES FOR NT USER *
 * ***************** *

 NT does not have the device category of 'MONITOR'.
 Driver files are not required for monitor setup. 
